{document.write("click on the character you choose to represent you")}
 {  
var charPlaying;
var enemyPlaying1;
var enemyPlaying2;
var enemyPlaying3;
var enemyPlaying4;
charPlaying="userclick1";
enemyPlaying1="userclick2";
enemyPlaying2="userclick3";
enemyPlaying3="userclick4";
enemyPlaying4="userclick5";
 };
 createEvent()
document.onkeyup=function(click){
    var userclick=event.click;
    if(userclick ==="Batman")
    $( init );

function init() {

 // Move the image from .myDiv1 to .myDiv3.
  $('.myDiv1').append( $('.myDiv3>Batman'))

  else if (userclick === "Superman")

  // Move the image from #Superman_img to #character_assault
  $('.myDiv1').append( $('.myDiv3>Superman'))

    else if(userclick === "Warrior_Princess")

// Move the image from #myDiv1 to #myDiv2
$('.myDiv1').append($('.myDiv3>Princess'))

    else if (userclick === "Pink_Sword")
}

var userclick=event.select;
if(userclick) === "Launch")
engage gunfire